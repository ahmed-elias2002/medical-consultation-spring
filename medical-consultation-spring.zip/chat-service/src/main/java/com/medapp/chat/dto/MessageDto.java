package com.medapp.chat.dto;
public class MessageDto { public String consultationId; public String from; public String text; public String date; }
