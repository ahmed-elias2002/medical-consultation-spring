package com.medapp.auth.controller;
import com.medapp.auth.model.User;
import com.medapp.auth.repository.UserRepository;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import java.util.Map;
@RestController
@RequestMapping("/auth")
public class AuthController {
    private final UserRepository userRepository;
    private final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
    public AuthController(UserRepository userRepository){ this.userRepository = userRepository; }
    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody Map<String,Object> body){
        String name = (String)body.get("name");
        String email = (String)body.get("email");
        String password = (String)body.get("password");
        String role = (String)body.getOrDefault("role","patient");
        var u = new User(); u.setName(name); u.setEmail(email); u.setPasswordHash(encoder.encode(password)); u.setRole(role); u.setVerified(false);
        userRepository.save(u);
        return ResponseEntity.ok(Map.of("id", u.getId(), "email", u.getEmail()));
    }
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String,String> body){
        var maybe = userRepository.findByEmail(body.get("email"));
        if(maybe.isEmpty()) return ResponseEntity.status(401).body(Map.of("error","Invalid"));
        var u = maybe.get();
        if(!encoder.matches(body.get("password"), u.getPasswordHash())) return ResponseEntity.status(401).body(Map.of("error","Invalid"));
        // For brevity return a dummy token. Replace with real JWT in production.
        String token = "DUMMY-TOKEN-FOR-"+u.getId();
        return ResponseEntity.ok(Map.of("token", token));
    }
}