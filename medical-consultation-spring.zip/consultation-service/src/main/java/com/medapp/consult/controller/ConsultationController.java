package com.medapp.consult.controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import java.util.Map;
@RestController
@RequestMapping("/consultations")
public class ConsultationController {
    @PostMapping
    public ResponseEntity<?> create(@RequestBody Map<String,Object> body){ return ResponseEntity.ok(Map.of("msg","created","body",body)); }
    @GetMapping("/{id}")
    public ResponseEntity<?> get(@PathVariable String id){ return ResponseEntity.ok(Map.of("id",id,"status","pending")); }
    @PostMapping("/{id}/assign")
    public ResponseEntity<?> assign(@PathVariable String id, @RequestBody Map<String,String> b){ return ResponseEntity.ok(Map.of("id",id,"doctorId",b.get("doctorId"))); }
}