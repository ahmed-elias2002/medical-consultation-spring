package com.medapp.admin.controller;import org.springframework.web.bind.annotation.*;import org.springframework.http.ResponseEntity;import java.util.Map;@RestController
@RequestMapping("/admin")
public class AdminController { @PostMapping("/verify-doctor") public ResponseEntity<?> verify(@RequestBody Map<String,Object> b){ return ResponseEntity.ok(Map.of("ok",true)); } }