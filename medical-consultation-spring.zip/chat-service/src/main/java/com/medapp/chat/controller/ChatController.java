package com.medapp.chat.controller;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;
import com.medapp.chat.dto.MessageDto;
@Controller
public class ChatController {
    @MessageMapping("/consultation.send")
    @SendTo("/topic/consultation")
    public MessageDto send(MessageDto msg){ return msg; }
}