# Medical Consultation Spring Monorepo (Skeleton)
Author: Ahmed Elias Ibrahim Zrain (ID: 120204167)

This repository contains minimal Spring Boot service skeletons for:
- gateway (Spring Cloud Gateway)
- auth-service
- user-service
- consultation-service
- chat-service
- admin-service

## How to run (development)
1. Install Docker and Maven (for local build without containers).
2. From repo root run: `docker-compose up --build`
3. Services will be available on ports: 8080, 4000, 4100, 4200, 4300, 4400

Notes:
- These are skeletons to get you started. Improve security (real JWT), add proper Maven wrappers, and implement business logic as needed.
